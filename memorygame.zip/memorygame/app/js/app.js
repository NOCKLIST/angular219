'use strict';
/* App Controllers */


var memoryGameApp = angular.module('memoryGameApp', []);


memoryGameApp.factory('game', function() {
  var tileNames = ['Che', 'Sadie-Mae-Glutz', 'Abstract-Guitarist-III', 'Blue-Bass', 'The-Double-Buddha', 'Red-Coats',
    'The-Waiter-of-Cannibals', 'Flowers-In-A-Tan-Vase'];

  return new Game(tileNames);
});


memoryGameApp.controller('GameCtrl', function GameCtrl($scope, game) {
  $scope.game = game;
});
