files = [
  JASMINE,
  JASMINE_ADAPTER,
  'app/lib/angular/angular.js',
  'app/js/app.js',
  'app/js/game.js',
  'test/lib/angular/angular-mocks.js',
  'test/unit/*.js'
];
autoWatch = true;
autoWatchInterval = 1;
logLevel = LOG_INFO;
logColors = true;
